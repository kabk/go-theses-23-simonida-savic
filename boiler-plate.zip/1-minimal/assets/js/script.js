$(document).ready(function() {

// functions go here

});