# A boilerplate template with 'boilerplate' CSS

Somewhat 'default' styling
